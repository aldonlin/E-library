﻿Partial Class LibraryDataSet
End Class

Namespace LibraryDataSetTableAdapters
    Partial Public Class EmployeesTableAdapter
    End Class
End Namespace
