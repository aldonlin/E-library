﻿Public Class MemberSearch
    Private Sub TitleTB_TextChanged(sender As Object, e As EventArgs) Handles TitleTB.TextChanged

    End Sub
End Class