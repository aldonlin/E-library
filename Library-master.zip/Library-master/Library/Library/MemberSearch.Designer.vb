﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MemberSearch
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Title = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Author = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Genre = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CheckoutPeriod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Available = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Info = New System.Windows.Forms.DataGridViewButtonColumn()
        Me.AuthorSearch = New System.Windows.Forms.Button()
        Me.TitleSearch = New System.Windows.Forms.Button()
        Me.AuthorTB = New System.Windows.Forms.TextBox()
        Me.TitleTB = New System.Windows.Forms.TextBox()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.SystemColors.ActiveCaption
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Title, Me.Author, Me.Genre, Me.CheckoutPeriod, Me.Available, Me.Info})
        Me.DataGridView1.Location = New System.Drawing.Point(52, 104)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(527, 243)
        Me.DataGridView1.TabIndex = 6
        '
        'Title
        '
        Me.Title.HeaderText = "Title"
        Me.Title.Name = "Title"
        '
        'Author
        '
        Me.Author.HeaderText = "Author"
        Me.Author.Name = "Author"
        '
        'Genre
        '
        Me.Genre.HeaderText = "Genre"
        Me.Genre.Name = "Genre"
        '
        'CheckoutPeriod
        '
        Me.CheckoutPeriod.HeaderText = "Checkout Period"
        Me.CheckoutPeriod.Name = "CheckoutPeriod"
        '
        'Available
        '
        Me.Available.HeaderText = "Available?"
        Me.Available.Name = "Available"
        '
        'Info
        '
        Me.Info.HeaderText = "More Info"
        Me.Info.Name = "Info"
        '
        'AuthorSearch
        '
        Me.AuthorSearch.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.AuthorSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.AuthorSearch.Location = New System.Drawing.Point(475, 68)
        Me.AuthorSearch.Name = "AuthorSearch"
        Me.AuthorSearch.Size = New System.Drawing.Size(75, 23)
        Me.AuthorSearch.TabIndex = 13
        Me.AuthorSearch.Text = "Search"
        Me.AuthorSearch.UseVisualStyleBackColor = False
        '
        'TitleSearch
        '
        Me.TitleSearch.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.TitleSearch.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.TitleSearch.Location = New System.Drawing.Point(475, 39)
        Me.TitleSearch.Name = "TitleSearch"
        Me.TitleSearch.Size = New System.Drawing.Size(75, 23)
        Me.TitleSearch.TabIndex = 12
        Me.TitleSearch.Text = "Search"
        Me.TitleSearch.UseVisualStyleBackColor = False
        '
        'AuthorTB
        '
        Me.AuthorTB.Location = New System.Drawing.Point(345, 69)
        Me.AuthorTB.Name = "AuthorTB"
        Me.AuthorTB.Size = New System.Drawing.Size(100, 20)
        Me.AuthorTB.TabIndex = 11
        Me.AuthorTB.Text = "Author Last Name"
        '
        'TitleTB
        '
        Me.TitleTB.Location = New System.Drawing.Point(345, 41)
        Me.TitleTB.Name = "TitleTB"
        Me.TitleTB.Size = New System.Drawing.Size(100, 20)
        Me.TitleTB.TabIndex = 10
        Me.TitleTB.Text = "Book Title"
        '
        'MemberSearch
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(641, 394)
        Me.Controls.Add(Me.AuthorSearch)
        Me.Controls.Add(Me.TitleSearch)
        Me.Controls.Add(Me.AuthorTB)
        Me.Controls.Add(Me.TitleTB)
        Me.Controls.Add(Me.DataGridView1)
        Me.Name = "MemberSearch"
        Me.Text = "MemberSearch"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Title As DataGridViewTextBoxColumn
    Friend WithEvents Author As DataGridViewTextBoxColumn
    Friend WithEvents Genre As DataGridViewTextBoxColumn
    Friend WithEvents CheckoutPeriod As DataGridViewTextBoxColumn
    Friend WithEvents Available As DataGridViewTextBoxColumn
    Friend WithEvents Info As DataGridViewButtonColumn
    Friend WithEvents AuthorSearch As Button
    Friend WithEvents TitleSearch As Button
    Friend WithEvents AuthorTB As TextBox
    Friend WithEvents TitleTB As TextBox
End Class
